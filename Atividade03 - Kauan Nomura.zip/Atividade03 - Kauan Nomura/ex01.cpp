#include <stdio.h>

int main()
{
	int media, a1, a2, a3 ,a4 ,a5;
	
	printf("Digite a nota do primeiro aluno:");
	scanf("%d",&a1);
	printf("Digite a nota do segundo aluno:");
	scanf("%d",&a2);
	printf("Digite a nota do terceiro aluno:");
	scanf("%d",&a3);
	printf("Digite a nota do quarto aluno:");
	scanf("%d",&a4);
	printf("Digite a nota do quinto aluno:");
	scanf("%d",&a5);
	
	media= (a1 + a2 + a3 + a4 + a5)/5;
	
	printf("a media de nota dos 5 alunos eh: %d", media);
	
	return 0;
}
