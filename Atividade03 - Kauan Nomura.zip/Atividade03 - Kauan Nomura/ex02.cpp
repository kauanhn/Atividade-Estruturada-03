#include <stdio.h>
  
int main()
{
	int idade;
	
	printf("qual a sua idade? ");
	scanf("%d", &idade);
	
	if (idade<30)
	{
		printf("voce eh muito jovem!");
	}	

	return 0;
}
