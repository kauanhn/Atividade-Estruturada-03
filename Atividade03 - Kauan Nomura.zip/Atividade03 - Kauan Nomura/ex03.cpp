#include <stdio.h>

int main()
{
	int idade;
	
	printf("qual a sua idade?: ");
	scanf("%d", &idade);
	
	if (idade>70)
	{
		printf("Novos 50");
	}
	else if(idade>21)
	{
		printf("Adulto");
	}
	else if(idade<21)
	{
		printf("Jovem");
	}
	
}
