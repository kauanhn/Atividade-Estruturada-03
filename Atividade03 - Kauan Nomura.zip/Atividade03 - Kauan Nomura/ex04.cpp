#include <stdio.h>
#include <math.h>

int main(){

	int idade;

	printf("Qual sua idade?: ");
	scanf("%d", &idade);
	
	
	if (idade <= 15 )
	{
	    if (idade <= 0)
	    { 
	    }
	    else
	    {
	        printf("nao vota\n");
	    }
	    
	}
	if (idade >= 16)
	{
	    if (idade <= 17)
	    {
	      printf("Opcional\n");
	    }
	}
	if (idade >= 18)
	{
		if (idade == 41)
	    {
	        printf("parabens,voce ganhou um premio e nao vota\n");
	    }
	
	    if (idade <= 65)
	    {
	      printf("obrigatorio\n");
	    }    
	if (idade > 65)
	    {
	        printf("Opcional\n");
	    }
	}
	if (idade ==88)
	{
	    printf("parabens,voce ganhou um premio e nao vota\n");
	}
	if (idade <= 0)
	{
	    printf("nao nasceu ainda\n");
	}

	
	return 0;	
}
